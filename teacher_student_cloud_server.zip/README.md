# Teacher + Student Video Maker — server-side edition

This project moves FFmpeg processing off the iPhone/browser and onto a Python server.

## Features
- Upload two videos (100 MB max per file by default).
- Server-side MP4 rendering using FFmpeg.
- Student-main with circular teacher inset, teacher-main with circular student inset, or side-by-side.
- Mix audio, teacher-first sequence, or select one voice.
- Optional FFmpeg `afftdn` noise reduction and volume adjustment.
- Optional automatic audio matching: cross-correlates the teacher clip's audio against the student clip's audio. It works best when the same teacher speech is clearly audible in both recordings. Low-confidence matches fall back to the manual student offset.
- Job status polling; the browser can be closed while the server continues processing (subject to hosting provider lifecycle).

## Important hosting note
Netlify Drop hosts static files; it cannot run this Python/FFmpeg backend. Deploy this repository to a Docker-capable host such as Render, Railway, Fly.io, or your own VPS. The included `render.yaml` and Dockerfile are a starting point. A persistent disk is recommended if you want generated MP4s to survive service restarts. The default local `/tmp` storage is temporary.

## Run locally
Requires Python 3.11+, FFmpeg and ffprobe installed.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open http://localhost:8000

## Deploy
1. Push this folder to a GitHub repository.
2. Create a new Docker web service on a host such as Render and connect the repository.
3. Set a persistent disk mounted at `/var/data` if available, then set `WORK_DIR=/var/data/jobs`.
4. Configure a service plan with enough RAM and disk for FFmpeg. For videos under 5 minutes and under 100 MB each, start with at least 2 GB RAM; more is safer.
5. Use HTTPS. Do not expose the backend without rate limits/authentication if it will be public.

## Limitations / production hardening
- This is a deployable starter, not an already-hosted public website.
- No login, payment, queue broker, or automatic file cleanup is included. Add authentication, per-user quotas, cleanup policy, and a persistent job queue before broad public use.
- Automatic sync is audio cross-correlation, not AI speech recognition. It may fail if the student clip does not contain the teacher's recorded speech, if there is heavy noise, or if audio processing changed the sound significantly.
- `afftdn` is conventional noise reduction, not guaranteed echo cancellation or AI source separation.
- For privacy, uploaded recordings are stored on the server until cleaned up. Add an explicit retention/deletion policy before real-world use.
