import os, uuid, shutil, subprocess, json, threading, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE=Path(__file__).resolve().parent
WORK=Path(os.getenv("WORK_DIR","/tmp/teacher-student-jobs"))
WORK.mkdir(parents=True,exist_ok=True)
MAX_BYTES=int(os.getenv("MAX_UPLOAD_BYTES", "104857600")) # 100 MB each
jobs={}
lock=threading.Lock()

app=FastAPI(title="Teacher + Student Video Maker API",version="1.0.0")
app.mount("/static",StaticFiles(directory=BASE/"static"),name="static")

@app.get("/")
def home():
    return FileResponse(BASE/"static"/"index.html")

def run(cmd):
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout)[-5000:])
    return p.stdout

def probe(path):
    data=json.loads(run(["ffprobe","-v","error","-show_streams","-show_format","-of","json",str(path)]))
    streams=data.get("streams",[])
    v=next((s for s in streams if s.get("codec_type")=="video"),None)
    a=next((s for s in streams if s.get("codec_type")=="audio"),None)
    if not v: raise RuntimeError(f"No video stream found in {path.name}")
    return {"video":v,"audio":a,"duration":float(data.get("format",{}).get("duration",0) or 0)}

def extract_mono(path,out):
    # Speech-band mono audio at 4 kHz keeps correlation memory reasonable.
    run(["ffmpeg","-y","-i",str(path),"-vn","-ac","1","-ar","4000","-t","240","-f","f32le",str(out)])
    import numpy as np
    return np.fromfile(out,dtype=np.float32)

def auto_offset(teacher_path,student_path,jobdir):
    try:
        import numpy as np
        from scipy.signal import correlate
        ta=extract_mono(teacher_path,jobdir/"teacher-sync.raw")
        sa=extract_mono(student_path,jobdir/"student-sync.raw")
        if len(ta)<4000 or len(sa)<4000: return None,"Not enough audio for automatic matching."
        # Use the first 90 seconds of teacher audio and search in student audio.
        ta=ta[:90*4000]
        # Remove DC and normalize; silence is not useful for alignment.
        ta=ta-np.mean(ta); sa=sa-np.mean(sa)
        ta=ta/(np.linalg.norm(ta)+1e-9); sa=sa/(np.linalg.norm(sa)+1e-9)
        # scipy's FFT correlation, valid mode returns candidate positions in student track.
        corr=correlate(sa,ta,mode="valid",method="fft")
        idx=int(np.argmax(np.abs(corr)))
        score=float(np.max(np.abs(corr)))
        # A weak match is more likely coincidental/noisy audio.
        if score < 0.025:
            return None,f"Automatic match confidence was low ({score:.3f}); used manual offset."
        return idx/4000.0,f"Matched teacher audio in student recording (confidence {score:.3f})."
    except Exception as e:
        return None,f"Automatic matching unavailable; used manual offset ({str(e)[:120]})."

def clean_audio(label,volume,denoise):
    chain=f"volume={float(volume):.3f}dB"
    if denoise: chain += ",highpass=f=90,lowpass=f=12000,afftdn=nf=-25"
    return f"[{label}:a]{chain},aresample=48000[{label}a]"

def process_job(job_id, teacher_path, student_path, opts):
    jobdir=WORK/job_id
    out=jobdir/"final.mp4"
    try:
        with lock: jobs[job_id].update(status="processing",progress=3,message="Checking video files…")
        tp=probe(teacher_path); sp=probe(student_path)
        offset=max(0,float(opts["student_start"]))
        sync_msg="Manual student start offset used."
        if opts["auto_sync"] and tp["audio"] and sp["audio"]:
            found,msg=auto_offset(teacher_path,student_path,jobdir)
            sync_msg=msg
            if found is not None: offset=found
        elif opts["auto_sync"]:
            sync_msg="Automatic matching needs audio in both clips; manual offset used."
        with lock: jobs[job_id].update(progress=15,message="Preparing video composition…",sync_message=sync_msg,student_offset=round(offset,2))
        # Video composition: scale/crop to 1280x720, teacher or student in circular inset.
        layout=opts["layout"]; inset=max(.18,min(.42,float(opts["inset_size"])/100))
        iw=int(1280*inset); ih=int(720*inset)
        iw += iw%2; ih += ih%2
        if layout=="side-by-side":
            vf="[0:v]scale=640:720:force_original_aspect_ratio=increase,crop=640:720,setsar=1[v0];[1:v]scale=640:720:force_original_aspect_ratio=increase,crop=640:720,setsar=1[v1];[v0][v1]hstack=inputs=2[base]"
            base="base"
        else:
            main_idx=1 if layout=="student-main" else 0
            inset_idx=0 if layout=="student-main" else 1
            vf=f"[{main_idx}:v]scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,setsar=1[main];[{inset_idx}:v]scale={iw}:{ih}:force_original_aspect_ratio=increase,crop={iw}:{ih},setsar=1,format=rgba,geq=lum='p(X,Y)':a='if(lte((X-W/2)^2+(Y-H/2)^2,(min(W,H)/2)^2),255,0)'[circle];[main][circle]overlay=W-w-32:32:format=auto[base]"
            base="base"
        # Academy title overlay (escape FFmpeg drawtext special chars).
        title=" | ".join(x for x in [opts["branch"],opts["student_class"],opts["state"]] if x).replace("\\","").replace(":","\\:").replace("'","\\'")
        if title:
            vf += f";[{base}]drawtext=text='{title}':fontcolor={opts['text_color']}:fontsize=30:box=1:boxcolor=black@0.48:boxborderw=12:x=28:y=h-th-24[vout]"
        else: vf += f";[{base}]null[vout]"
        cmd=["ffmpeg","-y","-i",str(teacher_path),"-ss",str(offset),"-i",str(student_path)]
        # Build audio filter graph, accounting for silent/no-audio inputs.
        has_t=bool(tp["audio"]); has_s=bool(sp["audio"])
        voice=opts["voice_order"]
        audio_graph=[]; audio_maps=[]
        if has_t:
            audio_graph.append(clean_audio("0",opts["teacher_volume"],opts["teacher_denoise"]))
            audio_maps.append("[0a]")
        if has_s:
            audio_graph.append(clean_audio("1",opts["student_volume"],opts["student_denoise"]))
            audio_maps.append("[1a]")
        if len(audio_maps)==2 and voice=="mix":
            audio_graph.append("[0a][1a]amix=inputs=2:duration=longest:dropout_transition=2,alimiter=limit=0.95[aout]")
            amap="[aout]"
        elif len(audio_maps)==2 and voice=="teacher-first":
            audio_graph.append("[0a][1a]concat=n=2:v=0:a=1[aout]"); amap="[aout]"
        elif len(audio_maps)==2 and voice=="teacher":
            audio_graph.append("[0a]anull[aout]"); amap="[aout]"
        elif len(audio_maps)==2 and voice=="student":
            audio_graph.append("[1a]anull[aout]"); amap="[aout]"
        elif len(audio_maps)==1:
            amap=audio_maps[0]
        else:
            amap=None
        fullgraph=vf
        if amap:
            fullgraph += ";"+";".join(audio_graph)
        cmd += ["-filter_complex",fullgraph,"-map","[vout]"]
        if amap: cmd += ["-map",amap]
        cmd += ["-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p","-c:a","aac","-b:a","160k","-movflags","+faststart","-shortest"]
        if float(opts["duration"])>0: cmd += ["-t",str(float(opts["duration"]))]
        cmd += [str(out)]
        with lock: jobs[job_id].update(progress=25,message="Rendering MP4 on the server…")
        # Server-side FFmpeg; process is not tied to the user's browser tab.
        run(cmd)
        if not out.exists() or out.stat().st_size==0: raise RuntimeError("FFmpeg did not create an output file.")
        with lock: jobs[job_id].update(status="completed",progress=100,message="Your MP4 is ready.",download_url=f"/api/jobs/{job_id}/download",output_size=out.stat().st_size)
    except Exception as e:
        with lock: jobs[job_id].update(status="failed",progress=100,message=str(e)[-1800:])

@app.post("/api/jobs")
async def create_job(background_tasks:BackgroundTasks,
    teacher:UploadFile=File(...), student:UploadFile=File(...),
    branch:str=Form(""), state:str=Form(""), student_class:str=Form(""),
    text_color:str=Form("white"), student_start:float=Form(0),
    auto_sync:bool=Form(False), voice_order:str=Form("mix"),
    student_denoise:bool=Form(True), teacher_denoise:bool=Form(False),
    teacher_volume:float=Form(0), student_volume:float=Form(0),
    layout:str=Form("student-main"), inset_size:float=Form(28), duration:float=Form(0)):
    if not teacher.filename or not student.filename: raise HTTPException(400,"Select both videos.")
    if layout not in ("student-main","teacher-main","side-by-side"): raise HTTPException(400,"Invalid layout.")
    if voice_order not in ("mix","teacher-first","teacher","student"): raise HTTPException(400,"Invalid voice setting.")
    job_id=uuid.uuid4().hex
    jobdir=WORK/job_id; jobdir.mkdir(parents=True)
    tpath=jobdir/"teacher-upload"; spath=jobdir/"student-upload"
    for upload,path in ((teacher,tpath),(student,spath)):
        size=0
        with path.open("wb") as f:
            while chunk:=await upload.read(1024*1024):
                size+=len(chunk)
                if size>MAX_BYTES:
                    shutil.rmtree(jobdir,ignore_errors=True)
                    raise HTTPException(413,"Each video must be 100 MB or smaller.")
                f.write(chunk)
    opts={"branch":branch[:100],"state":state[:60],"student_class":student_class[:60],
      "text_color":text_color if text_color in ("white","black","yellow","red","blue") else "white",
      "student_start":max(0,student_start),"auto_sync":auto_sync,"voice_order":voice_order,
      "student_denoise":student_denoise,"teacher_denoise":teacher_denoise,
      "teacher_volume":max(-30,min(12,teacher_volume)),"student_volume":max(-30,min(12,student_volume)),
      "layout":layout,"inset_size":max(18,min(42,inset_size)),"duration":max(0,duration)}
    with lock: jobs[job_id]={"status":"queued","progress":0,"message":"Upload complete; waiting for server processor."}
    background_tasks.add_task(process_job,job_id,tpath,spath,opts)
    return {"job_id":job_id,"status":"queued"}

@app.get("/api/jobs/{job_id}")
def get_job(job_id:str):
    with lock: job=jobs.get(job_id)
    if not job: raise HTTPException(404,"Job not found (server may have restarted).")
    return {"job_id":job_id,**job}

@app.get("/api/jobs/{job_id}/download")
def download(job_id:str):
    path=WORK/job_id/"final.mp4"
    with lock: job=jobs.get(job_id)
    if not job or job.get("status")!="completed" or not path.exists(): raise HTTPException(404,"Video is not ready.")
    return FileResponse(path,media_type="video/mp4",filename="teacher-student-combined.mp4")

@app.get("/health")
def health(): return {"ok":True}
